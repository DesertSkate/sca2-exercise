# Day 1, Exercise AM: JavaScript Basic Training

Fill in all of the functions in `drills.js`.

To run your programs, `cd` into this subdirectory in the terminal and then run `node drills.js`. You can test your functions by adding `assert` statements at the bottom of the file as follows
