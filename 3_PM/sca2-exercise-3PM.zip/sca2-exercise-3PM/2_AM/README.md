# Day 2, Exercise AM: Git

Get as far in the following set of exercises as possible:

https://github.com/jlord/git-it-electron
