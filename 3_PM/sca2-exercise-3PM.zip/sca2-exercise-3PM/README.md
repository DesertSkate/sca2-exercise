# SCA 2 Exercises

Exercises for the 2019 SCA 2
 
