# Day 1, Exercise PM: Advanced JavaScript

For each file, complete the assigned task.

Once you have `cd`ed into this subdirectory, you can run your programs with `node FILE_NAME`. You can test using `assert` statements (make sure to add `const assert = require('assert')` at the top of your file if you wish to do so), or `console.log()` statements.
