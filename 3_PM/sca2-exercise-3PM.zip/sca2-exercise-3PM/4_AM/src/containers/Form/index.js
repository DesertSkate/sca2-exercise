import React, { Component } from "react"
import Welcome from "../../components/Welcome"

class Home extends Component {
  render() {
    // Currently, this only renders the welcome component. Create a form, and various form components and place them here
    return <Welcome />
  }
}

export default Home
