import React from "react"
import { Container, Text } from "./styles"

const Welcome = () => (
  <Container>
    <Text>SCA 2 Web Starter!</Text>
  </Container>
)

export default Welcome
